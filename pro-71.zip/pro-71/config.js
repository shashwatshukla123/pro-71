import * as firebase from 'firebase';

const firebaseConfig = {
    apiKey: "AIzaSyBzW1Ur5TUJ26v4T8xyeqWhgQOEf9TH2J8",
    authDomain: "spectagram-95caf.firebaseapp.com",
    databaseURL: "https://spectagram-95caf-default-rtdb.firebaseio.com",
    projectId: "spectagram-95caf",
    storageBucket: "spectagram-95caf.appspot.com",
    messagingSenderId: "365293733097",
    appId: "1:365293733097:web:fa30e536283acc5f0fdc78"
  };

firebase.initializeApp(firebaseConfig);

export default firebase.firestore();